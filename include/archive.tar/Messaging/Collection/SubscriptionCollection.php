<?php
namespace CDash\Messaging\Collection;

use CDash\Messaging\Subscription\UserSubscription;

/**
 * Class SubscriptionCollection
 * @package CDash\Messaging\Collection
 */
class SubscriptionCollection extends Collection
{
    public function addSubscription(UserSubscription $subscription)
    {
        parent::add($subscription);
    }

    public function add($item, $name = null)
    {
        $this->addSubscription($item);
    }
}
