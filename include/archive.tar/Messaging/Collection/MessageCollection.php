<?php
namespace CDash\Messaging\Collection;

class MessageCollection extends Collection
{

}
