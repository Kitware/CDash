<?php
namespace CDash\Messaging;


class SubscriptionBuilderFactory
{
    public function createSubscription(\ActionableBuildInterface $build)
    {

    }
}
