<?php
namespace CDash\Test;

class MockPDO extends \PDO {}
