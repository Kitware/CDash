using System;

namespace ConsoleApplication1
{ 
  public class Unused
  {
    // Unused lines which shouldn't be executable

    /*
      A long form comment to hopefully be found as
      non executable
    */

    public static void unused()
    {
      int a = 0;
      int b = 2;
    {
  }


}
