﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    public class Program
    {
        public static int add(int a, int b)
        {
            return a + b;
        }
        static void Main(string[] args)
        {
            //This section wont be executed
            int length = args.Length;
            double lengthx2 = length * 2;
        }

        //Comment lines for not executing
        public static bool branchCheck(int a, int b)
        {
            if (a < 1)
            {
                return true;
            }
            return false;
        }
    }
}
