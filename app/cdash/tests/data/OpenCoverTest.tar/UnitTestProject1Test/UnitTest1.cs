﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using ConsoleApplication1;


namespace UnitTestProject1Test
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
            Assert.AreEqual(4, ConsoleApplication1.Program.add(2, 2));
        }
        [TestMethod]
        public void TestMethod2()
        {
            Assert.IsTrue(ConsoleApplication1.Program.branchCheck(0, 0));
            Assert.IsFalse(ConsoleApplication1.Program.branchCheck(4, 0));
        }
    }
}
